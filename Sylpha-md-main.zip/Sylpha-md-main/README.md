<img src="https://readme-typing-svg.herokuapp.com/?font=mono&size=30&duration=4000&color=836FFF&center=falso&vCenter=falso&lines=ＳＹＬＰＨＡ－ＭＤ－2.5✓;𝐁𝐎𝐓+𝐌𝐔𝐋𝐓𝐈+𝐃𝐄𝐕𝐈𝐂𝐄;1500+𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒+2025;Ｏｂｅｒｏｎ✰✰✰✰✰">      

<h1 align="center">
<p>
<img src= "https://files.catbox.moe/h9nw7i.jpg" alt="SYLPHA MD V2.5✓" width="720">
</p>

<p align="center">
<a href="#"><img src="https://img.shields.io/badge/BOT-MULTI--DEVICE-blue?style=for-the-badge" alt="BOT MULTI DEVICE"></a>
<a href="#"><img src="https://img.shields.io/badge/Autor-@Kairune-orange?style=for-the-badge&logo=github" alt="Autor"></a>
<a href="#"><img src="https://img.shields.io/badge/Versão-V2.5-orange?style=for-the-badge&logo=github" alt="Versão"></a>
</p>

---

---

## 📥 Instalação no Termux

<div align="center">
<img src="https://user-images.githubusercontent.com/108157095/182052725-6568419a-6a9f-490a-85ea-90b94af694fe.png" alt="Termux" height="30">
</div>

Siga os passos abaixo para instalar o bot:

1. **Atualize e instale dependencias:**
 ```bash
 apt-get upgrade && apt-get update && pkg upgrade -y && pkg update -y && pkg install nodejs -y && pkg install nodejs-lts -y && pkg install ffmpeg -y && pkg install wget -y && pkg install git -y
 ```

2. **Configure o armazenamento do Termux:**
 ```bash
 termux-setup-storage
 ```

3. **Acesse o diretorio do armazenamento:**
 ```bash
 cd /sdcard/
 ```

4. **Clone o repositorio do bot:**
 ```bash
 git clone https://github.com/Oberonhosting/Sylpha-md.git
 ```

5. **Entre no diretorio do bot:**
 ```bash
 cd Sylpha-md
 ```

---

## 🚀 Iniciando o Bot

<div align="center">
<img src="https://user-images.githubusercontent.com/108157095/182053901-78e4a217-51ba-42a3-8ec5-38ed978ad752.png" alt="Iniciar Bot" height="30">
</div>

Para iniciar o bot, execute o comando:

```bash
sh start.sh
```

---

## 🎉 Recursos do Bot

- **Interface Dinâmica:** Experiência visual moderna e interativa.
- **Compatibilidade Multi-Device:** Acesse de qualquer dispositivo.
- **Atualizações Constantes:** Fique sempre por dentro das últimas novidades.
- **1500+ Comandos:** Uma ampla gama de funcionalidades para você explorar.

---

## 📊 Estatísticas e Suporte

<div align="center">
<img src="https://github-readme-stats.vercel.app/api?username=Oberonhosting&show_icons=true&theme=radical" alt="Estatísticas GitHub">
</div>

Se encontrar algum problema ou tiver sugestões, sinta-se à vontade para abrir uma [issue](https://github.com/Oberonhosting/Sylpha-md/issues) ou contribuir com o projeto.

---

<img src="https://readme-typing-svg.herokuapp.com/?font=mono&size=30&duration=4000&color=00FA9A&center=falso&vCenter=falso&lines=𝖆+𝕽𝖊𝖆𝖑𝖊𝖟𝖆+𝕯𝖔𝖒𝖎𝖓𝖆^-^;@lucas_mod_domina;Ｏｂｅｒｏｎ✰✰✰✰✰">     
